﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft.Bot.Connector")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyProduct("Microsoft Bot Framework")]
[assembly: AssemblyCopyright("Copyright © Microsoft Corporation 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("3.15.2.2")]
[assembly: AssemblyFileVersion("3.15.2.2")]

//[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
//[assembly: AssemblyDelaySignAttribute(true)]

[assembly: AssemblyKeyFileAttribute(@"..\\..\\buildtools\\35MSSharedLib1024.snk")] 
 [assembly: AssemblyDelaySignAttribute(true)]
